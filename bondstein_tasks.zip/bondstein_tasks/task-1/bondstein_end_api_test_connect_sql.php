<?php
// Simple product reviews endpoint with database connection and input validation

// Checking the request method 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read and decode the incoming JSON data
     $input_data = json_decode(file_get_contents("php://input"), true);
    
    // Validate the required fields
    $errorMessages = [];

    if (!isset($input_data['product_id']) || empty($input_data['product_id'])) {
        $errorMessages[] = 'Product ID is required';
    } elseif (!is_numeric($input_data['product_id'])) {
        $errorMessages[] = 'Invalid product ID (must be numeric)';
    }

    if (!isset($input_data['user_id']) || empty($input_data['user_id'])) {
        $errorMessages[] = 'User ID is required';
    } elseif (!is_numeric($input_data['user_id'])) {
        $errorMessages[] = 'Invalid user ID (must be numeric)';
    }

    if (!isset($input_data['review_text']) || empty($input_data['review_text'])) {
        $errorMessages[] = 'Review text is required';
    }

    // Check for errors
    if (empty($errorMessages)) {
        // Process the review
        $productId = $input_data['product_id'];
        $userId = $input_data['user_id'];
        $reviewText = $input_data['review_text'];

        // Database connection parameters
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'end_point_api';

        // Create a database connection
        $conn = new mysqli($host, $username, $password, $database);

        // Check the connection
        if ($conn->connect_error) {
            die('Connection failed: ' . $conn->connect_error);
        }

        // Save the review to the database
        $stmt = $conn->prepare('INSERT INTO reviews (product_id, user_id, review_text) VALUES (?, ?, ?)');
        $stmt->bind_param('iis', $productId, $userId, $reviewText);
        $stmt->execute();
        $stmt->close();

        // Close the database connection
        $conn->close();

        // Send a success response
        $response = ['status' => 'success', 'message' => 'Review submitted successfully'];
    } else {
        // Send an error response with specific error messages
        $response = ['status' => 'error', 'message' => 'Invalid input data', 'errors' => $errorMessages];
    }
} else {
    // Send an error response for unsupported request method
    $response = ['status' => 'error', 'message' => 'Unsupported request method'];
}

// Set the response header to JSON
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);
?>
