<?php
function PairWithSum($nums, $target) {
    $left_number = 0;
    $right_number = count($nums) - 1;

    while ($left_number < $right_number) {
        $currentSum = $nums[$left_number] + $nums[$right_number];

        if ($currentSum == $target) {
            return [$left_number, $right_number];
        } elseif ($currentSum < $target) {
            $left_number++;
        } else {
            $right_number--;
        }
    }

    return null;
}

$numbers = [1, 2, 4, 7, 11, 15];
$targetNumberSum = 15;

$result = PairWithSum($numbers, $targetNumberSum);

if ($result !== null) {
    echo "Indices of the pair with sum $targetNumberSum:(" . implode(', ', $result).")<br>";
     $values = $numbers[$result[0]] . ' and ' . $numbers[$result[1]];
     echo "Values at these indices are respectively: $values";
} else {
    echo "No pair found with sum $targetNumberSum\n";
}
